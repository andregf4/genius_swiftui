//
//  GeminiApp.swift
//  Gemini
//
//  Created by Andre Gerez Foratto on 04/07/24.
//

import SwiftUI

@main
struct GeminiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
